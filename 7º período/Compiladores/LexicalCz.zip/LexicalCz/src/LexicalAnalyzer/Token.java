package LexicalAnalyzer;

public enum Token {
    KEYWORD, VARIABLE_NAME, FUNCTION_NAME, WHITESPACE, ERROR, PALAVRA_CHAVE;
}
