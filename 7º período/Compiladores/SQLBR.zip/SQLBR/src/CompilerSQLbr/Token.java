package CompilerSQLbr;

/**
 *
 * @author aluno
 */
public enum Token {
    PL, ID, CTE, INT, DEC, OPARITM, OPCOMP, OPLOG, SIMB_ESPEC, ERROR, BRANCO, ASPAS_DUPLAS;
}
